CATEGORIES = (
    "Beverages",
    "Fruits",
    "Vegetables",
    "Sports",
    "Films",
    "Car",
    "Business",
    "Music",
    "Tablets",
    "TV",
    "Table Games",
    "PC Games",
    "Motorbike",
    "Outdoors",
    "Handmade",
    "Radio",
    "Books",
    "Fashion",
    "Electronics",
    "Car Electronics",
)
PRODUCT_UNITS_PIECE = 1
PRODUCT_UNITS_GRAMS = 2
PRODUCT_UNITS_KILOGRAMS = 3
PRODUCT_UNITS_LITERS = 4
